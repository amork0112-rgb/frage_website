import { createClient, type SupabaseClient } from "@supabase/supabase-js";

declare global {
  var __supabase__: SupabaseClient | undefined;
}

const url = process.env.NEXT_PUBLIC_SUPABASE_URL ?? "";
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "";

if (!url || !key) {
  throw new Error("Missing Supabase environment variables");
}

export const supabase: SupabaseClient =
  globalThis.__supabase__ ??
  createClient(url, key, {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
    },
  });

if (!globalThis.__supabase__) {
  globalThis.__supabase__ = supabase;
}
