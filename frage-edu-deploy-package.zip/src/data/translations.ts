export const translations = {
  en: {
    nav: {
      about: "About",
      programs: "Programs",
      campuses: "Campuses",
      admissions: "Admissions",
      news: "News",
      community: "Community",
      inquire: "Inquire",
    },
    hero: {
      location: "Since 2002 • Daegu, South Korea",
      title_1: "The Standard of",
      title_2: "Excellence",
      subtitle: "More than learning English.\nWe empower students to think, debate, and persuade on the global stage.",
      cta_admissions: "Admissions",
      cta_discover: "Discover",
      scroll: "Scroll",
    },
    stats: {
      items: [
        { label: "Founded", value: "2002" },
        { label: "Campuses", value: "4" },
        { label: "Curriculum Tracks", value: "12+" },
        { label: "Alumni Network", value: "2,500+" },
      ],
    },
    philosophy: {
      title_1: "English as a",
      title_2: "Weapon",
      quote: "\"We don't just teach English; we create a stage for students to think, speak, and persuade.\"",
      point_1_title: "Competition-Based Curriculum",
      point_1_desc: "Through English debate, presentations, and creative convergence competitions, students naturally acquire advanced vocabulary, logical structure, and self-expression.",
      point_2_title: "Growth-Tracking System",
      point_2_desc: "From kindergarten to middle school, we manage growth using Lexile, standardized tests, and internal indicators—focusing on 'what level of thinking reached' rather than 'how many books solved'.",
    },
    gallery: {
      label: "Our Environment",
      title: "A Space for Inspiration",
    },
    programs: {
      label: "Curriculum",
      title: "Academic Journey",
      view_all: "View All Programs",
      explore: "Explore",
      items: [
        {
          age: "AGE 1-3",
          title: "Little Frage",
          desc: "A sensory-rich environment where language acquisition begins naturally through play and immersion.",
        },
        {
          age: "AGE 5-7",
          title: "Kindergarten",
          desc: "Building the foundation of phonics and expression in a warm, encouraging atmosphere.",
        },
        {
          age: "GRADE 1-6",
          title: "Elementary",
          desc: "Deep reading and structured writing to develop critical thinking and logical argumentation.",
        },
        {
          age: "GRADE 7-12",
          title: "Secondary",
          desc: "Mastery of academic English for global university admissions and professional leadership.",
        },
      ],
    },
    cta: {
      title_1: "Begin the",
      title_2: "Legacy",
      desc: "Join a community of families who value true intellectual growth.",
      button: "Inquire for Admission",
    },
    footer: {
      manifesto: "We are not just teaching English. We are cultivating the intellectual leaders of tomorrow through deep reading, critical debate, and global awareness.",
      programs_title: "Programs",
      campuses_title: "Campuses",
      copyright: "© 2024 FRAGE EDU. All rights reserved.",
      admin: "Admin",
      privacy: "Privacy Policy",
    },
  },
  ko: {
    nav: {
      about: "학원 소개",
      programs: "교육과정",
      campuses: "캠퍼스 안내",
      admissions: "입학 안내",
      news: "소식",
      community: "학부모 커뮤니티",
      inquire: "상담 예약",
    },
    hero: {
      location: "Since 2002 • 대구 수성구",
      title_1: "탁월함의",
      title_2: "새로운 기준",
      subtitle: "아이들이 영어를 배우는 곳이 아니라,\n영어로 생각하고, 발표하고, 설득하는 무대에 서게 하는 곳입니다.",
      cta_admissions: "입학 안내",
      cta_discover: "학원 소개",
      scroll: "Scroll",
    },
    stats: {
      items: [
        { label: "설립 연도", value: "2002" },
        { label: "캠퍼스", value: "4" },
        { label: "교육 과정", value: "12+" },
        { label: "졸업생 네트워크", value: "2,500+" },
      ],
    },
    philosophy: {
      title_1: "영어를",
      title_2: "무기로",
      quote: "\"몇 권을 풀었는지가 아니라, 어떤 사고 수준까지 도달했는지를 관리합니다.\"",
      point_1_title: "대회 중심 커리큘럼",
      point_1_desc: "영어 디베이트, 프레젠테이션, 창의·융합형 대회 참여 경험을 통해 고급 어휘와 논리 구조, 자기 표현력을 체득합니다.",
      point_2_title: "성장 추적형 시스템",
      point_2_desc: "유치부부터 중등까지 하나의 성장 트랙으로 연결됩니다. Lexile, 공인 시험, 내부 지표로 아이의 언어 사고력 성장을 입체적으로 관리합니다.",
    },
    gallery: {
      label: "교육 환경",
      title: "영감을 주는 공간",
    },
    programs: {
      label: "커리큘럼",
      title: "성장의 여정",
      view_all: "전체 프로그램 보기",
      explore: "자세히 보기",
      items: [
        {
          age: "만 1-3세",
          title: "리틀 프라게",
          desc: "놀이와 몰입을 통해 자연스럽게 언어 습득이 시작되는 감각적인 교육 환경입니다.",
        },
        {
          age: "5-7세",
          title: "유치부",
          desc: "따뜻하고 격려하는 분위기 속에서 파닉스와 표현력의 기초를 다집니다.",
        },
        {
          age: "초등 1-6학년",
          title: "초등부",
          desc: "깊이 있는 독서와 체계적인 글쓰기를 통해 비판적 사고와 논리적 논증력을 키웁니다.",
        },
        {
          age: "중·고등부",
          title: "중·고등 입시반",
          desc: "글로벌 대학 입시와 전문적 리더십을 위한 최상위 학술 영어를 완성합니다.",
        },
      ],
    },
    cta: {
      title_1: "위대한 여정의",
      title_2: "시작",
      desc: "진정한 지적 성장을 가치 있게 여기는 프라게 커뮤니티와 함께하세요.",
      button: "입학 상담 신청",
    },
    footer: {
      manifesto: "우리는 단순히 영어를 가르치지 않습니다. 깊이 있는 독서, 비판적 토론, 글로벌 인식을 통해 내일의 지적 리더를 양성합니다.",
      programs_title: "교육 프로그램",
      campuses_title: "캠퍼스",
      copyright: "© 2024 프라게 에듀. All rights reserved.",
      admin: "관리자 로그인",
      privacy: "개인정보처리방침",
    },
  },
};

export type Language = "en" | "ko";
export type Translation = typeof translations.en;
