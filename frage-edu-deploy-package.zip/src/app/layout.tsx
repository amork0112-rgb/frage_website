import { ReactNode } from "react";
import { Playfair_Display, Inter, Noto_Sans_KR } from "next/font/google";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import KakaoCTA from "@/components/KakaoCTA";
import "./globals.css";
import type { Metadata } from "next";
import { LanguageProvider } from "@/context/LanguageContext";

const playfair = Playfair_Display({ 
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap",
});

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap",
});

const notoSansKr = Noto_Sans_KR({
  subsets: ["latin"],
  weight: ["100", "300", "400", "500", "700", "900"],
  variable: "--font-noto-sans-kr",
  display: "swap",
});

export const metadata: Metadata = {
  title: "FRAGE EDU | Premium English Education",
  description: "Cultivating critical thinkers and global leaders.",
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ko" className={`${playfair.variable} ${inter.variable} ${notoSansKr.variable}`}>
      <body className="flex min-h-screen flex-col font-sans font-premium-style bg-frage-cream text-frage-navy antialiased selection:bg-frage-gold selection:text-frage-navy">
        <LanguageProvider>
          <Header />
          <div className="flex-grow">
            {children}
          </div>
          <Footer />
          <KakaoCTA />
        </LanguageProvider>
      </body>
    </html>
  );
}
