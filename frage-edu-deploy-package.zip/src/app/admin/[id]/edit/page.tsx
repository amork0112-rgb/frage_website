"use client";

import { useEffect, useState } from "react";
import { useRouter, useParams } from "next/navigation";
import { supabase } from "@/lib/supabase";
import ReactMarkdown from "react-markdown";

export default function EditPostPage() {
  const router = useRouter();
  const params = useParams();
  const id = params.id as string;

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<"news" | "notice" | "community">(
    "news"
  );
  const [published, setPublished] = useState(false);
  const [pinned, setPinned] = useState(false);
  const [coverImage, setCoverImage] = useState<string | null>(null);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  /* -----------------------------
     기존 글 불러오기
  ----------------------------- */
  useEffect(() => {
    async function loadPost() {
      const { data, error } = await supabase
        .from("posts")
        .select("*")
        .eq("id", id)
        .single();

      if (error || !data) {
        setError("글을 불러올 수 없습니다.");
        setLoading(false);
        return;
      }

      setTitle(data.title);
      setContent(data.content);
      setCategory(data.category);
      setPublished(data.published);
      setPinned(data.pinned ?? false);
      setCoverImage(data.cover_image ?? null);

      setLoading(false);
    }

    loadPost();
  }, [id]);

  /* -----------------------------
     이미지 업로드
  ----------------------------- */
  async function uploadImage(file: File) {
    const filePath = `${Date.now()}-${file.name}`;

    const { error } = await supabase.storage
      .from("post-images")
      .upload(filePath, file);

    if (error) throw error;

    const { data } = supabase.storage
      .from("post-images")
      .getPublicUrl(filePath);

    return data.publicUrl;
  }

  /* -----------------------------
     수정 저장
  ----------------------------- */
  async function handleUpdate() {
    setSaving(true);
    setError(null);

    const { error } = await supabase
      .from("posts")
      .update({
        title,
        content,
        category,
        published,
        pinned,
        cover_image: coverImage,
      })
      .eq("id", id);

    setSaving(false);

    if (error) {
      setError(error.message);
      return;
    }

    router.push("/admin");
  }

  /* -----------------------------
     삭제
  ----------------------------- */
  async function handleDelete() {
    const ok = confirm("정말 이 글을 삭제하시겠습니까?");
    if (!ok) return;

    const { error } = await supabase.from("posts").delete().eq("id", id);

    if (error) {
      setError(error.message);
      return;
    }

    router.push("/admin");
  }

  if (loading) {
    return <p className="p-10 text-sm">불러오는 중...</p>;
  }

  return (
    <section className="mx-auto max-w-3xl py-10 space-y-6">
      <header className="space-y-1">
        <h1 className="text-2xl font-semibold">글 수정</h1>
        <p className="text-sm text-slate-600">
          내용 수정, 공개 여부, 상단 고정 및 삭제를 관리합니다.
        </p>
      </header>

      {error && <p className="text-sm text-red-600">{error}</p>}

      {/* 제목 */}
      <input
        className="w-full border px-3 py-2 text-lg"
        placeholder="제목"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />

      {/* 카테고리 */}
      <select
        className="border px-3 py-2"
        value={category}
        onChange={(e) =>
          setCategory(e.target.value as "news" | "notice" | "community")
        }
      >
        <option value="news">Frage News (공개)</option>
        <option value="notice">공지 (학부모)</option>
        <option value="community">커뮤니티</option>
      </select>

      {/* 옵션 */}
      <div className="flex gap-6 text-sm">
        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={published}
            onChange={(e) => setPublished(e.target.checked)}
          />
          공개
        </label>

        <label className="flex items-center gap-2">
          <input
            type="checkbox"
            checked={pinned}
            onChange={(e) => setPinned(e.target.checked)}
          />
          상단 고정
        </label>
      </div>

      {/* 이미지 업로드 */}
      <div className="space-y-2">
        <label className="text-sm font-medium">대표 이미지</label>
        <input
          type="file"
          accept="image/*"
          onChange={async (e) => {
            if (!e.target.files?.[0]) return;
            const url = await uploadImage(e.target.files[0]);
            setCoverImage(url);
          }}
        />
        {coverImage && (
          <img
            src={coverImage}
            alt="cover"
            className="max-h-48 rounded border"
          />
        )}
      </div>

      {/* Markdown 입력 */}
      <div className="space-y-2">
        <label className="text-sm font-medium">본문 (Markdown)</label>
        <textarea
          className="w-full border p-3 h-56 font-mono text-sm"
          value={content}
          onChange={(e) => setContent(e.target.value)}
        />
      </div>

      {/* Markdown 미리보기 */}
      <div className="border p-4 bg-slate-50 rounded">
        <p className="text-xs text-slate-500 mb-2">미리보기</p>
        <ReactMarkdown>{content}</ReactMarkdown>
      </div>

      {/* 액션 버튼 */}
      <div className="flex gap-3 pt-4">
        <button
          onClick={handleUpdate}
          disabled={saving}
          className="bg-black text-white px-4 py-2 rounded"
        >
          {saving ? "저장 중..." : "수정 저장"}
        </button>

        <button
          onClick={() => router.back()}
          className="border px-4 py-2 rounded"
        >
          취소
        </button>

        <button
          onClick={handleDelete}
          className="border border-red-500 text-red-600 px-4 py-2 rounded ml-auto"
        >
          삭제
        </button>
      </div>
    </section>
  );
}
