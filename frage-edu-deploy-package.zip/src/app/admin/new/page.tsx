"use client";

import { useState } from "react";
import { supabase } from "@/lib/supabase";
import { useRouter } from "next/navigation";

export default function AdminNewPostPage() {
  const router = useRouter();

  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState("news");
  const [published, setPublished] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSave() {
    setLoading(true);
    setError(null);

    const { error } = await supabase.from("posts").insert({
      title,
      content,
      category,
      published,
    });

    setLoading(false);

    if (error) {
      setError(error.message);
      return;
    }

    router.push("/admin");
  }

  return (
    <section className="mx-auto max-w-2xl py-10 space-y-4">
      <h1 className="text-xl font-semibold">새 글 작성</h1>

      <input
        className="w-full border px-3 py-2"
        placeholder="제목"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />

      <textarea
        className="w-full border px-3 py-2 h-48"
        placeholder="내용"
        value={content}
        onChange={(e) => setContent(e.target.value)}
      />

      <select
        className="w-full border px-3 py-2"
        value={category}
        onChange={(e) => setCategory(e.target.value)}
      >
        <option value="news">Frage News (공개)</option>
        <option value="notice">공지 (학부모)</option>
        <option value="community">커뮤니티</option>
      </select>

      <label className="flex items-center gap-2">
        <input
          type="checkbox"
          checked={published}
          onChange={(e) => setPublished(e.target.checked)}
        />
        바로 공개
      </label>

      {error && <p className="text-red-600 text-sm">{error}</p>}

      <button
        onClick={handleSave}
        disabled={loading}
        className="bg-black text-white px-4 py-2 rounded"
      >
        {loading ? "저장 중..." : "저장"}
      </button>
    </section>
  );
}
