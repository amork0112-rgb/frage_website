import { redirect } from "next/navigation";
import { createServerClient } from "@supabase/ssr";

export default async function NewsPostPage({
  params
}: {
  params: { id: string };
}) {
  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL ?? "",
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ?? "",
    {
      cookies: {
        get: () => undefined,
        set: () => {},
        remove: () => {}
      }
    }
  );

  const { data: post } = await supabase
    .from("posts")
    .select("id, title, content, category, created_at, author_role")
    .eq("id", params.id)
    .eq("category", "Frage News")
    .single();

  if (!post) {
    redirect("/news");
  }

  const date = new Date(post.created_at);
  const formatted = new Intl.DateTimeFormat("ko-KR", {
    year: "numeric",
    month: "short",
    day: "numeric"
  }).format(date);

  return (
    <article className="mx-auto max-w-3xl py-10">
      <h1 className="text-2xl font-semibold">{post.title}</h1>
      <p className="mt-1 text-sm text-slate-600">
        {post.category} • {formatted} • {post.author_role}
      </p>
      <div className="prose mt-6 max-w-none">
        {post.content}
      </div>
    </article>
  );
}

