import React from "react";
import Link from "next/link";

export default function NewsPage() {
  // Placeholder news data
  const newsItems = [
    {
      id: 1,
      category: "Notice",
      title: "2025학년도 신입생 모집 설명회 안내",
      date: "2024.12.10",
      summary: "내년도 신입생 모집을 위한 학부모 설명회가 각 캠퍼스별로 진행됩니다. 일정과 예약 방법을 확인하세요."
    },
    {
      id: 2,
      category: "Event",
      title: "Winter Reading Challenge 우수 학생 시상",
      date: "2024.11.25",
      summary: "지난 겨울방학 동안 진행된 리딩 챌린지에서 목표를 달성한 학생들의 시상식이 있었습니다."
    },
    {
      id: 3,
      category: "Academic",
      title: "TOEFL Primary/Junior 정기 시험 일정",
      date: "2024.11.10",
      summary: "공인 인증 시험을 통해 아이들의 객관적인 실력을 점검해볼 수 있는 기회입니다."
    }
  ];

  return (
    <main className="min-h-screen bg-white pb-20">
      <section className="bg-white py-16 border-b border-slate-100">
        <div className="container mx-auto px-6">
          <h1 className="text-3xl font-bold text-frage-navy md:text-4xl">News & Notice</h1>
          <p className="mt-2 text-slate-500">
            프라게 에듀의 새로운 소식을 전해드립니다.
          </p>
        </div>
      </section>

      <section className="container mx-auto mt-12 px-6 max-w-5xl">
        <div className="grid gap-6">
          {newsItems.map((item) => (
            <div key={item.id} className="group flex flex-col md:flex-row gap-6 p-6 rounded-xl border border-slate-100 hover:border-frage-primary/30 transition-colors bg-white hover:shadow-sm">
              <div className="md:w-32 flex-shrink-0 flex flex-col justify-center">
                <span className={`inline-block w-fit px-2 py-1 text-xs font-semibold rounded ${
                  item.category === 'Notice' ? 'bg-red-50 text-red-600' :
                  item.category === 'Event' ? 'bg-orange-50 text-orange-600' :
                  'bg-blue-50 text-blue-600'
                }`}>
                  {item.category}
                </span>
                <span className="mt-2 text-sm text-slate-400">{item.date}</span>
              </div>
              <div className="flex-grow">
                <h3 className="text-xl font-bold text-slate-900 group-hover:text-frage-primary transition-colors">
                  {item.title}
                </h3>
                <p className="mt-2 text-slate-600">
                  {item.summary}
                </p>
              </div>
            </div>
          ))}
        </div>
        
        {/* Pagination Placeholder */}
        <div className="mt-12 flex justify-center">
            <button className="px-4 py-2 text-slate-400 hover:text-frage-primary disabled:opacity-50" disabled>
                &larr; Prev
            </button>
            <div className="flex space-x-2 mx-4">
                <button className="w-8 h-8 rounded-full bg-frage-primary text-white flex items-center justify-center font-medium">1</button>
                <button className="w-8 h-8 rounded-full hover:bg-slate-100 text-slate-600 flex items-center justify-center font-medium">2</button>
                <button className="w-8 h-8 rounded-full hover:bg-slate-100 text-slate-600 flex items-center justify-center font-medium">3</button>
            </div>
            <button className="px-4 py-2 text-slate-600 hover:text-frage-primary">
                Next &rarr;
            </button>
        </div>
      </section>
    </main>
  );
}
