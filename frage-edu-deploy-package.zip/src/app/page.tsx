"use client";

import Link from "next/link";
import { ArrowRight, Play } from "lucide-react";
import { useLanguage } from "@/context/LanguageContext";

export default function HomePage() {
  const { t } = useLanguage();

  return (
    <div className="flex flex-col min-h-screen font-sans bg-frage-cream selection:bg-frage-gold selection:text-frage-navy">
      
      {/* 1. Hero Section: Fullscreen Cinematic */}
      <section className="relative h-screen w-full overflow-hidden">
        {/* Background Image/Video Overlay */}
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1577896334614-5498f93638c4?q=80&w=2070&auto=format&fit=crop" 
            alt="International School Debate" 
            className="w-full h-full object-cover transform scale-105 animate-slow-zoom"
          />
          <div className="absolute inset-0 bg-frage-navy/40 mix-blend-multiply" />
          <div className="absolute inset-0 bg-gradient-to-t from-frage-navy/80 via-transparent to-transparent" />
        </div>

        {/* Hero Content */}
        <div className="relative z-10 container mx-auto px-6 h-full flex flex-col justify-center items-center text-center">
          <span className="text-frage-gold font-bold tracking-[0.3em] uppercase text-xs md:text-sm mb-6 animate-fade-in-up">
            {t.hero.location}
          </span>
          <h1 className="font-serif text-5xl md:text-7xl lg:text-8xl text-white font-medium leading-tight mb-8 max-w-4xl animate-fade-in-up delay-100 drop-shadow-lg">
            {t.hero.title_1} <br/>
            <span className="italic font-light">{t.hero.title_2}</span>
          </h1>
          <p className="text-white/90 text-lg md:text-xl font-medium tracking-wide max-w-2xl leading-relaxed mb-12 animate-fade-in-up delay-200 whitespace-pre-line drop-shadow-md">
            {t.hero.subtitle}
          </p>
          
          <div className="flex flex-col md:flex-row gap-6 animate-fade-in-up delay-300">
            <Link 
              href="/admissions" 
              className="px-10 py-4 bg-white text-frage-navy font-bold tracking-widest uppercase text-xs hover:bg-frage-gold hover:text-white transition-all duration-500 min-w-[200px]"
            >
              {t.hero.cta_admissions}
            </Link>
            <Link 
              href="/about" 
              className="px-10 py-4 border border-white/30 text-white font-bold tracking-widest uppercase text-xs hover:bg-white hover:text-frage-navy transition-all duration-500 min-w-[200px] backdrop-blur-sm"
            >
              {t.hero.cta_discover}
            </Link>
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-10 left-1/2 transform -translate-x-1/2 flex flex-col items-center gap-2 animate-bounce-slow z-20">
          <span className="text-white/50 text-[10px] tracking-widest uppercase">{t.hero.scroll}</span>
          <div className="w-[1px] h-12 bg-gradient-to-b from-white to-transparent opacity-50"></div>
        </div>
      </section>

      {/* 1.5. Key Stats: Authority & Trust (International School Style) */}
      <section className="bg-frage-navy py-12 border-b border-white/10 relative z-20 -mt-2">
        <div className="container mx-auto px-6 max-w-[1200px]">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 md:gap-12">
            {t.stats.items.map((stat, index) => (
              <div key={index} className="text-center group">
                <span className="block text-3xl md:text-4xl font-serif text-frage-gold mb-2 group-hover:scale-110 transition-transform duration-300">
                  {stat.value}
                </span>
                <span className="text-white/60 text-xs font-bold tracking-widest uppercase">
                  {stat.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 2. Philosophy Section: Editorial Layout */}
      <section className="py-32 bg-frage-cream">
        <div className="container mx-auto px-6 max-w-[1200px]">
          <div className="flex flex-col md:flex-row gap-16 items-start">
            <div className="md:w-1/3">
              <span className="block w-12 h-[2px] bg-frage-gold mb-8"></span>
              <h2 className="font-serif text-4xl md:text-5xl text-frage-navy leading-tight">
                {t.philosophy.title_1} <br/>
                <span className="italic text-frage-gold">{t.philosophy.title_2}</span>
              </h2>
            </div>
            <div className="md:w-2/3">
              <p className="text-xl md:text-2xl text-frage-navy font-medium leading-relaxed mb-12 whitespace-pre-line">
                {t.philosophy.quote}
              </p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div>
                  <h3 className="font-serif text-2xl text-frage-navy mb-4 font-bold">{t.philosophy.point_1_title}</h3>
                  <p className="text-frage-gray leading-relaxed text-base font-medium tracking-wide">
                    {t.philosophy.point_1_desc}
                  </p>
                </div>
                <div>
                  <h3 className="font-serif text-2xl text-frage-navy mb-4 font-bold">{t.philosophy.point_2_title}</h3>
                  <p className="text-frage-gray leading-relaxed text-base font-medium tracking-wide">
                    {t.philosophy.point_2_desc}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Campus Visuals: Parallax / Masonry */}
      <section className="py-20 bg-white overflow-hidden">
        <div className="container mx-auto px-6 max-w-[1400px]">
          <div className="text-center mb-20">
            <span className="text-frage-gold font-bold tracking-[0.2em] uppercase text-xs">{t.gallery.label}</span>
            <h2 className="font-serif text-4xl text-frage-navy mt-4">{t.gallery.title}</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4 h-[1200px] md:h-[600px]">
            {/* Main Feature Image */}
            <div className="md:col-span-8 h-[300px] md:h-full relative overflow-hidden group">
               <img 
                 src="https://images.unsplash.com/photo-1544531696-297afda2ad6c?q=80&w=2086&auto=format&fit=crop" 
                 alt="Students in Library Discussion" 
                 className="w-full h-full object-cover transition-transform duration-[1.5s] group-hover:scale-105"
               />
               <div className="absolute inset-0 bg-frage-navy/20 group-hover:bg-transparent transition-colors duration-500"></div>
            </div>
            
            {/* Secondary Grid */}
            <div className="md:col-span-4 flex flex-col gap-4 h-full">
              <div className="flex-1 relative overflow-hidden group">
                <img 
                  src="https://images.unsplash.com/photo-1427504494785-3a9ca7044f45?auto=format&fit=crop&w=800&q=80" 
                  alt="Active Classroom Learning" 
                  className="w-full h-full object-cover transition-transform duration-[1.5s] group-hover:scale-105"
                />
              </div>
              <div className="flex-1 relative overflow-hidden group">
                <img 
                  src="https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&w=800&q=80" 
                  alt="Creative Learning Materials" 
                  className="w-full h-full object-cover transition-transform duration-[1.5s] group-hover:scale-105"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Programs: Minimal & Elegant */}
      <section className="py-32 bg-frage-navy text-white">
        <div className="container mx-auto px-6 max-w-[1200px]">
          <div className="flex flex-col md:flex-row justify-between items-end mb-20 border-b border-white/10 pb-10">
            <div>
              <span className="text-frage-gold font-bold tracking-[0.2em] uppercase text-xs">{t.programs.label}</span>
              <h2 className="font-serif text-4xl md:text-5xl mt-4">{t.programs.title}</h2>
            </div>
            <Link href="/programs" className="hidden md:flex items-center text-sm font-bold tracking-widest uppercase hover:text-frage-gold transition-colors mt-8 md:mt-0">
              {t.programs.view_all} <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {t.programs.items.map((program, index) => (
              <div key={index} className="group border-t border-white/20 pt-8 hover:border-frage-gold transition-colors duration-300">
                <span className="block text-frage-gold text-xs font-bold tracking-widest mb-4">{program.age}</span>
                <h3 className="font-serif text-2xl mb-4 group-hover:text-frage-gold transition-colors">{program.title}</h3>
                <p className="text-white/60 text-sm leading-relaxed mb-8 h-20">
                  {program.desc}
                </p>
                <Link href="/programs" className="inline-block border-b border-transparent group-hover:border-frage-gold pb-1 text-xs tracking-widest uppercase">
                  {t.programs.explore}
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 5. Final CTA: Minimalist */}
      <section className="relative py-40 bg-frage-cream flex items-center justify-center text-center overflow-hidden">
         {/* Background Decor */}
         <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-frage-gold/5 rounded-full blur-3xl pointer-events-none"></div>

         <div className="relative z-10 max-w-3xl px-6">
           <h2 className="font-serif text-5xl md:text-6xl text-frage-navy mb-8 font-medium">
             {t.cta.title_1} <span className="italic text-frage-gold">{t.cta.title_2}</span>
           </h2>
           <p className="text-lg text-frage-gray mb-12 font-medium">
             {t.cta.desc}
           </p>
           <Link 
             href="/admissions" 
             className="inline-block px-12 py-5 bg-frage-navy text-white font-bold tracking-[0.2em] uppercase text-xs hover:bg-frage-gold transition-colors duration-500 shadow-xl"
           >
             {t.cta.button}
           </Link>
         </div>
      </section>

    </div>
  );
}