import React from "react";

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-frage-sand/30 pb-20">
      {/* Hero Section */}
      <section className="relative bg-frage-navy py-20 text-white">
        <div className="container mx-auto px-6 text-center">
          <h1 className="mb-4 text-3xl font-bold md:text-4xl">
            Education Philosophy
          </h1>
          <p className="text-frage-sand/80">
            Why we teach, and how we guide your children.
          </p>
        </div>
      </section>

      {/* Philosophy Content */}
      <section className="container mx-auto mt-16 max-w-4xl px-6">
        <div className="space-y-12">
          {/* Core Philosophy */}
          <div className="rounded-2xl bg-white p-10 shadow-sm border border-slate-100">
            <h2 className="mb-6 text-2xl font-bold text-frage-primary">
              소리에서 시작하여 사고로 확장합니다
            </h2>
            <div className="space-y-4 text-lg leading-relaxed text-slate-700">
              <p>
                EFL(English as a Foreign Language) 환경인 한국에서, 영어 교육의
                시작은 단순히 문자를 읽는 것이 아닙니다. <strong>소리(Sound)</strong>에 대한
                정확한 이해와 노출이 언어 습득의 가장 견고한 기초가 됩니다.
              </p>
              <p>
                프라게 에듀는 아이들이 영어의 고유한 소리를 체화하는 것에서 시작하여,
                텍스트를 읽고(Reading), 그 안에 담긴 의미를 사고(Thinking)하며,
                자신의 언어로 표현(Speaking & Writing)하는 논리적 순서를 따릅니다.
              </p>
            </div>
          </div>

          {/* Director's Message */}
          <div className="grid gap-10 md:grid-cols-2 items-center">
            <div className="order-2 md:order-1">
              <h3 className="mb-4 text-xl font-bold text-frage-navy">
                하나의 철학, 다양한 경로
              </h3>
              <p className="text-slate-600 leading-relaxed">
                모든 아이가 같은 속도로 성장하지 않습니다. 그러나 성장의 방향은 명확해야 합니다.
                우리는 <strong>'비판적 사고를 동반한 언어 능력'</strong>이라는 하나의 목표를 향해,
                아이의 현재 수준과 성향에 맞춘 최적의 교육 경로를 제시합니다.
                <br /><br />
                단순한 암기가 아닌, 스스로 생각하고 질문을 던지는 힘을 기르는 것.
                이것이 프라게가 지향하는 글로벌 인재의 모습입니다.
              </p>
            </div>
            <div className="order-1 md:order-2 h-64 rounded-xl bg-frage-forest/10 flex items-center justify-center text-frage-forest font-serif italic text-xl p-8 text-center">
              "Language is not just a tool for communication, but a vessel for thought."
            </div>
          </div>

          {/* Evaluation System */}
          <div className="rounded-2xl bg-slate-50 p-10 border border-slate-200">
            <h3 className="mb-4 text-xl font-bold text-frage-navy">
              평가와 기록이 있는 교육
            </h3>
            <p className="text-slate-600 leading-relaxed">
              성장은 막연한 느낌이 아니라 구체적인 데이터로 확인되어야 합니다.
              프라게는 정기적인 평가와 상세한 성장 기록을 통해 학부모님과 투명하게 소통합니다.
              아이의 Reading Level, 논리적 말하기 능력, 에세이 작성 능력 등
              핵심 역량의 변화를 체계적으로 관리합니다.
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
