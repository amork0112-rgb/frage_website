import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        frage: {
          navy: "#0A192F", // Deep Royal Navy
          gold: "#C5A059", // Muted Metallic Gold
          cream: "#FAF9F6", // Expensive Paper
          gray: "#4A5568", // Darker Slate Gray for better readability (was #8892b0)
          white: "#FFFFFF",
          "navy-light": "#112240",
          "gold-light": "#E5C585",
        },
      },
      fontFamily: {
        serif: ["var(--font-playfair)", "MaruBuri", "serif"],
        sans: ["var(--font-inter)", "var(--font-noto-sans-kr)", "sans-serif"],
        kr: ["var(--font-noto-sans-kr)", "sans-serif"],
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
      },
      animation: {
        'slow-zoom': 'zoom 20s infinite alternate',
        'fade-in-up': 'fadeInUp 1s ease-out forwards',
        'bounce-slow': 'bounce 3s infinite',
      },
      keyframes: {
        zoom: {
          '0%': { transform: 'scale(1)' },
          '100%': { transform: 'scale(1.1)' },
        },
        fadeInUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
      },
    },
  },
  plugins: [],
};
export default config;
